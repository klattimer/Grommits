/** 
    Handle widget preferences and associated UI 

    Copyright: John Buckley (cocoa.coder@gmail.com)
    July 2005

    DISCLAIMER: This computer program is supplied "AS IS".
    The Author disclaims all warranties, expressed or implied, including,
    without limitation, the warranties of merchantability and of fitness
    for  any purpose.  The Author assumes no liability for direct, indirect,
    incidental, special, exemplary, or consequential damages, which may
    result from the use of the computer program, even if advised of the
    possibility of such damage.  There is no warranty against interference
    with your enjoyment of the computer program or against infringement.
    There is no warranty that my efforts or the computer program will
    fulfill any of your particular purposes or needs.  This computer
    program is provided with all faults, and the entire risk of satisfactory
    quality, performance, accuracy, and effort is with the user.

    LICENSE: Permission is hereby irrevocably granted to everyone to use,
    copy, modify, and distribute this computer program, or portions hereof,
    purpose, without payment of any fee, subject to the following
    restrictions:

    1. The origin of this binary or source code must not be misrepresented.

    2. Altered versions must be plainly marked as such and must not be
    misrepresented as being the original binary or source.

    3. The Copyright notice, disclaimer, and license may not be removed
    or altered from any source, binary, or altered source distribution.
*/

var prefsDoneClicked = false;
var prefsVisible = false;

var updateHost = 'http://www.olivetoast.com';

function showPrefs()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");

    document.getElementById( "fliprollie" ).style.display = "none";

    // Set-up state
    document.getElementById( "location-input" ).value = prefs.locationShortName;
    if ( prefs.useCelcius ) {
        document.getElementById( "temp-scale-input" ).value = "degC";
    } 
    else {
        document.getElementById( "temp-scale-input" ).value = "degF";
    }

    document.getElementById( "theme-input" ).value = prefs.themePath;
    document.getElementById( "highlight-extreme-temp" ).checked = prefs.highlightExtremeTemp;

    if (window.widget) {
        widget.prepareForTransition("ToBack");
    }
                
    front.style.display="none";
    back.style.display="block";

    if (window.widget) {
        setTimeout ('widget.performTransition();', 0); 
    }

    prefsDoneClicked = false;
    prefsVisible = true;
}

function hidePrefs()
{
    prefsDoneClicked = true;
    prefsVisible = false;

    // If a location has not been validated then abort the hide and do the validation.
    if ( isLocationInputPending() && !isValidatingLocation ) {
        validateLocationInput();
        return;
    }

    clearAboutUpdate();

    var front = document.getElementById("front");
    var back = document.getElementById("back");
        
    if (window.widget)
        widget.prepareForTransition("ToFront");
                
    back.style.display="none";
    front.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}

function createLocalPrefKey(key)
{
    // Create a local widget preference key
    return widget.identifier + "-" + key;
}

function storePrefs() 
{
    if ( window.widget ) {
        // Note: don't persist locationId - it's better to fetch this each time to ensure mobile & location ids are kept in sync
        if ( prefs.mobileId )
            window.widget.setPreferenceForKey( prefs.mobileId, createLocalPrefKey("mobile-id") );
        if ( prefs.locationShortName )
            window.widget.setPreferenceForKey( prefs.locationShortName, createLocalPrefKey("location-short-name") );
        if ( prefs.locationLongName )
            window.widget.setPreferenceForKey( prefs.locationLongName, createLocalPrefKey("location-long-name") );
        window.widget.setPreferenceForKey( prefs.themePath, createLocalPrefKey("theme-path") );
        window.widget.setPreferenceForKey( prefs.useCelcius, createLocalPrefKey("celcius") );
        window.widget.setPreferenceForKey( prefs.highlightExtremeTemp, createLocalPrefKey("highlight-extreme-temp") );

        // Also store the pref without our id so that closing and re-opening the widget
        // restores the last used location
        if ( prefs.mobileId )
            window.widget.setPreferenceForKey( prefs.mobileId, "mobile-id" );
        if ( prefs.locationShortName )
            window.widget.setPreferenceForKey( prefs.locationShortName, "location-short-name" );
        if ( prefs.locationLongName )
            window.widget.setPreferenceForKey( prefs.locationLongName, "location-long-name" );
        window.widget.setPreferenceForKey( prefs.themePath, "theme-path" );
        window.widget.setPreferenceForKey( prefs.useCelcius, "celcius" );
        window.widget.setPreferenceForKey( prefs.highlightExtremeTemp, "highlight-extreme-temp" );
    }
}

function getPrefForKey( key ) {

    if ( !window.widget ) return undefined;

    var pref = window.widget.preferenceForKey( createLocalPrefKey(key) );

    // Try without the widget identifier if the pref didn't exist. This means
    // we can remember prefs after closing and re-opening the widget
    if ( !pref ) pref = window.widget.preferenceForKey( key );

    return pref;
}

function readPrefs()
{
    prefs.mobileId = getPrefForKey( "mobile-id" );
    prefs.locationShortName = getPrefForKey( "location-short-name" );
    prefs.locationLongName = getPrefForKey( "location-long-name" );
    prefs.themePath = getPrefForKey("theme-path");
    prefs.useCelcius = getPrefForKey( "celcius" );
    prefs.highlightExtremeTemp = getPrefForKey( "highlight-extreme-temp" );
}

// Input handlers
function locationKeyPress( event )
{
    // If it's a return key that was pressed then validate the input
    switch (event.keyCode) {
    case 13: // return  
    case 3:  // enter
    case 9:  // tab
        validateLocationInput();
        break;

    case 27: // escape
        endLocationValidation();
        break;
    }
}

function tempScaleChanged( select )
{
    if ( select.value == "degC" ) {
        prefs.useCelcius = true;
    }
    else { 
        prefs.useCelcius = false;
    }

    storePrefs();
    updateWeatherData();
}

function themeChanged( select )
{
    prefs.themePath = select.value;

    storePrefs();
    updateWeatherData();
}

function highlightExtremeTempChanged( event )
{
    prefs.highlightExtremeTemp = document.getElementById( "highlight-extreme-temp" ).checked;
    storePrefs();
    updateWeatherData();
}

function enterFlip( event )
{
    document.getElementById("fliprollie").style.display="block";
}

function exitFlip( event )
{
    document.getElementById("fliprollie").style.display="none";
}

// Fading 'i' support
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};
function mousemove(event)
{
    if (!flipShown)
    {
        if (animation.timer != null)
        {
            clearInterval(animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById('flip');
        animation.timer = setInterval("animate();", 13);
        animation.from = animation.now;
        animation.to = 1.0;
        animate();
        flipShown = true;
    }
}

function mouseout(event)
{
    if (flipShown)
    {
        // fade in the info button
        if (animation.timer != null)
        {
            clearInterval(animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById('flip');
        animation.timer = setInterval("animate();", 13);
        animation.from = animation.now;
        animation.to = 0.0;
        animate();
        flipShown = false;

        // And make sure the fliprollie is hidden too
        document.getElementById("fliprollie").style.display="none";
    }
}

function animate()
{
    function limit_3 (a, b, c)
    {
        return a < b ? b : (a > c ? c : a);
    }
    function computeNextFloat (from, to, ease)
    {
        return from + (to - from) * ease;
    }

    var T;
    var ease;
    var time = (new Date).getTime();
        
    T = limit_3(time-animation.starttime, 0, animation.duration);
        
    if (T >= animation.duration)
    {
        clearInterval(animation.timer);
        animation.timer = null;
        animation.now = animation.to;
    }
    else
    {
        ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
        animation.now = computeNextFloat(animation.from, animation.to, ease);
    }
        
    animation.firstElement.style.opacity = animation.now;
}

function checkForUpdates()
{
    if ( versionNumber === undefined )
        getVersionNumber(true); // then update
    else
        createXMLRequest( updateHost + "/BBCWeather/version.xml", parseVersionXml ).send();
}

function parseVersionXml( event, request )
{
    var update = false;

    // Get the version number element
    var thisVersion = 0.0;
    var result = versionNumber.match(/(\d)\.(\d)\.?(\d)?/);
    if ( result && result.length >= 3 ) {
        thisVersion = parseFloat(result[1] + "." + result[2] + (result.length == 4 ? result[3] : ""));
    }

    debug("thisVersion: " + thisVersion );

    try {
        var response = request.responseXML;

        // Convert to a float e.g. "0.9.7" -> 0.97
        var version = parseFloat( $("major", response).text() + "." + $('minor', response).text() + $('revision', response).text() );
        debug("Remote version: " + version );
        update = (version > thisVersion);
        debug("update?: " + update );
    } 
    catch(e) {
        debug( "Warning: Failed to part version xml" );
    }

    $('#new-version-badge').css('display', update ? 'inline' : 'none');

    if ( prefsVisible )  { // show some info in prefs mode
        if ( update ) {
            $('#about-update').text('A new version is available');
            $('#about-update').css('text-decoration', 'underline');
            $('#about-update').bind('click', openNewVersionUrl);
        }
        else {
            $('#about-update').text('You have the latest version');
            $('#about-update').css('text-decoration', 'none');
            $('#about-update').unbind('click');
            setTimeout( 'clearAboutUpdate();', 2000 );
        }

        $("#about-bbc").css('display', "none");
        $("#about-update").css('display', "block");
    }
}

function clearAboutUpdate()
{
    $("#about-bbc").css('display', "block");
    $("#about-update").css('display', "none");
}

function getVersionNumber(doUpdateCheck)
{
    createXMLRequest( "Info.plist", parseVersion, doUpdateCheck ).send();
}

function parseVersion(event, request, doUpdateCheck) 
{
    try {
        var response = request.responseXML;
        var key, i = 0;
        while ((key = response.getElementsByTagName("key")[i++])) {
            if (key.firstChild.data == "CFBundleVersion") break;
        }
        if (key) {
            var string = key.nextSibling;
            while (string && string.nodeType != 1) {
                string = string.nextSibling;
            }
            versionNumber = string ? string.firstChild.data : undefined;
        }
    } catch (ex) {
        debug( "Warning: parseVersion failed" );
    }

    $('#version').text( "v" + (versionNumber ? versionNumber : '?') );

    if ( doUpdateCheck )
        checkForUpdates();
}

function openNewVersionUrl()
{
    openUrl( updateHost + '/BBCWeather/newversion.shtml');
    clearAboutUpdate();
}