/**
   Fetch and validate a location

    Copyright: John Buckley (cocoa.coder@gmail.com)
    July 2005

    DISCLAIMER: This computer program is supplied "AS IS".
    The Author disclaims all warranties, expressed or implied, including,
    without limitation, the warranties of merchantability and of fitness
    for  any purpose.  The Author assumes no liability for direct, indirect,
    incidental, special, exemplary, or consequential damages, which may
    result from the use of the computer program, even if advised of the
    possibility of such damage.  There is no warranty against interference
    with your enjoyment of the computer program or against infringement.
    There is no warranty that my efforts or the computer program will
    fulfill any of your particular purposes or needs.  This computer
    program is provided with all faults, and the entire risk of satisfactory
    quality, performance, accuracy, and effort is with the user.

    LICENSE: Permission is hereby irrevocably granted to everyone to use,
    copy, modify, and distribute this computer program, or portions hereof,
    purpose, without payment of any fee, subject to the following
    restrictions:

    1. The origin of this binary or source code must not be misrepresented.

    2. Altered versions must be plainly marked as such and must not be
    misrepresented as being the original binary or source.

    3. The Copyright notice, disclaimer, and license may not be removed
    or altered from any source, binary, or altered source distribution.
*/

var isValidatingLocation = false;
var validateAnimTimerId = 0;

var menuPopupX = 40;
var menuPopupY = 83;

var searchUrl = "http://www.bbc.co.uk/cgi-perl/weather/search/new_search.pl?tmpl=pda2&search_query=%s";

function searchFrame() {
    return document.getElementById('search_frame');
}

function validateLocationInput()
{
    var location = $('#location-input').val().strip();
    debug('validateLocationInput: %s', location);

    if ( location == prefs.locationShortName )
        return;

     isValidatingLocation = true;
     searchFrame().onload = searchFrameDidLoad;
     searchFrame().src = searchUrl.format(escape(location));

    // Animate...(the location-caption :)
    if ( !validateAnimTimerId ) {
        validateAnimTimerId = setInterval( function() { loadingAnimation(validateAnimTimerId) }, 500 );
        loadingAnimData[validateAnimTimerId] = { text:"Validating", node:"#location-caption", count:3 };
    }
    loadingAnimation(validateAnimTimerId);
}

function searchFrameDidLoad()
{
    var frame = searchFrame();

    if ( frame.contentDocument.URL == 'about:blank' )
        return;

    if ( frame.contentDocument.readyState != 'complete' ) {
        locationProcessed({errorString:"Request failed"});
        return;
    }

    var results = [];
    try {
        // If there is a single match the forecast URL is returned
        var id = frame.contentDocument.URL.firstMatch(/5day\.shtml\?((id|world)\=[0-9]+)/);
        if ( id ) {
            // Extract the location name
            var name = $('h1', frame.contentDocument).text().firstMatch(/5 day forecast for ([\w\d\s]+)/i);
            if ( name ) {
                name = name.strip();
                results.push({id:id, shortName:name, longName:name});
            }
        }
        else {
            // Parse the search results

            // Synchronously fetch location from wml page - this is used to translate a postcode result
            // to a proper location name
            function getLocationSynchronously(id) {
                request = new XMLHttpRequest();
                request.open('GET', fiveDayWmlUrl.format(id), false);
                request.overrideMimeType('text/xml');
                request.send();

                try {
                    if ( request.status == 200 && request.responseXML )
                        return $('card p b:first', request.responseXML).text();
                }
                catch(e) {
                    debug('getLocationSynchronously error: %s', e);
                }

                return null;
            };

            // <p><b>UK towns|postcode</b></p><ul><li><a href=..../>
            $('.linkList p', frame.contentDocument).each( function() {
                    var items = [];
                    var ul = $('~ ul', this).get(0); // first sibling only
                    $('a', ul).each( function() {
                            var item = {};
                            item.id = this.href.firstMatch(/5day\.shtml\?((id|world)\=[0-9]+)/);
                            item.longName = $(this).text();

                            // If it's a postcode, get the 'real' location
                            if ( item.longName.match(/\b[a-z]{1,2}[0-9]{1,2}\b/i) ) {
                                var loc = getLocationSynchronously(item.id);
                                if ( loc )
                                    item.longName = loc;
                            }

                            item.shortName = item.longName.split(',')[0];
                            if ( item.id && item.longName && item.shortName )
                                items.push(item);
                        });
                    if ( items.length ) {
                        // Insert a 'title' item  
                        results.push({longName: $(this).text()});
                        results = results.concat(items);
                    }
                });
        }
    }
    catch(e) {
        debug('Warning, search parse error: %s', e);
    }

    if ( results.length )
        showLocationsMenu(results);
    else
        locationProcessed({errorString:"No locations found"});
}

function showLocationsMenu(results)
{
    // Build the menu
    var menu = (window.widget ? window.widget.createMenu() : null);
    if ( menu ) {
        var i = 0;
        results.forEach( function(item) {
                menu.addMenuItem(item.longName);
                if ( item.id === undefined )
                    menu.setMenuItemEnabledAtIndex(i, false); // title
                ++i;
            } );

        // Show the menu
        var selection = menu.popup( menuPopupX, menuPopupY );
        if ( selection >= 0 && selection < results.length ) {
            locationProcessed(results[selection]);
        }
        else {
            locationProcessed({errorString:"No locations chosen"});
        }
    }
    else {
        // Just choose the first (non-title) result
        locationProcessed( (results.length > 1 ? results[1] : results[0]) );
    }
}

function locationProcessed( result )
{
    //debug('locationProcessed: %s, %s', result.id, result.shortName);

    isValidatingLocation = false;
    searchFrame().src = 'about:blank';

    if ( !result.errorString && result.id ) {
        // Get the location chooseice...
        prefs.mobileId = result.id;
        prefs.locationId = null; // needs re-fetching in updateWeatherData
        prefs.locationShortName = result.shortName;
        prefs.locationLongName = result.longName;
        storePrefs();

        endLocationValidation();
        updateWeatherData();
    } 
    else {
        debug( "Location processing error: " + result.errorString );
        endLocationValidation(result.errorString);
    }

    // If our done-button was clicked then hide prefs
    if ( prefsDoneClicked ) {
        $('#location-input').val(prefs.locationShortName); // Force locationValid so hidePrefs does not abort
        hidePrefs();
        prefsDoneClicked = false;
    }
}

function endLocationValidation( errorStr ) 
{
    if ( validateAnimTimerId ) {
        clearInterval( validateAnimTimerId );
        loadingAnimData[validateAnimTimerId] = undefined;
        validateAnimTimerId = 0;
    }

    // Reset the location caption
    $( "#location-caption" ).text("Enter a location or postcode:");

    // And set the location name
    if ( !errorStr )
        $('#location-input').val(prefs.locationShortName);
    else {
        // Let the user know something went wrong
        menu = (window.widget ? window.widget.createMenu() : null);
        if ( menu ) {
            menu.addMenuItem( errorStr );
            menu.setMenuItemEnabledAtIndex( 0, false );
            menu.popup( menuPopupX, menuPopupY );
        }
        else {
            $( "#location-input" ).val(errorStr);
        }
    }
}

function isLocationInputPending()
{
    return $('#location-input').val() != prefs.locationShortName;
}