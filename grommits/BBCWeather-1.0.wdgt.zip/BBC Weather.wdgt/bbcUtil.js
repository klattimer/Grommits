/** BBC Weather widget: Fetches info from the BBC's wap weather source 
    
    Copyright: John Buckley (cocoa.coder@gmail.com)
    July 2005

    DISCLAIMER: This computer program is supplied "AS IS".
    The Author disclaims all warranties, expressed or implied, including,
    without limitation, the warranties of merchantability and of fitness
    for  any purpose.  The Author assumes no liability for direct, indirect,
    incidental, special, exemplary, or consequential damages, which may
    result from the use of the computer program, even if advised of the
    possibility of such damage.  There is no warranty against interference
    with your enjoyment of the computer program or against infringement.
    There is no warranty that my efforts or the computer program will
    fulfill any of your particular purposes or needs.  This computer
    program is provided with all faults, and the entire risk of satisfactory
    quality, performance, accuracy, and effort is with the user.

    LICENSE: Permission is hereby irrevocably granted to everyone to use,
    copy, modify, and distribute this computer program, or portions hereof,
    purpose, without payment of any fee, subject to the following
    restrictions:

    1. The origin of this binary or source code must not be misrepresented.

    2. Altered versions must be plainly marked as such and must not be
    misrepresented as being the original binary or source.

    3. The Copyright notice, disclaimer, and license may not be removed
    or altered from any source, binary, or altered source distribution.
*/

function createXMLRequest( url, onload, user_data, method )
{
    if ( !method )
        method = 'GET';

    var xml_request = new XMLHttpRequest();
    if ( onload )
        xml_request.onload = function(e) { onload( e, xml_request, user_data ) };
    //xml_request.overrideMimeType( mime );
    xml_request.open(method, url);
    xml_request.setRequestHeader("Cache-Control", "no-cache");
    return xml_request;
}

function printDOMNode( node )
{
    for ( var child = node.firstChild; child; child=child.nextSibling ) {
        if ( child.hasChildNodes() ) printDOMNode( child );

        debug( child + ": " + child.data );
    }
}

function dumpObject(obj, name)
{
    if ( name )
        debug('%s:', name);
    for ( var key in obj )
        debug('%s: %s', key, obj[key]);
}

// Write to the debug div when in Safari.
// Send a simple alert to Console when in Dashboard.
function debug(str) 
{
    if (debugMode) {
        if ( arguments.length > 1 ) {
            // This is a bit messy, but we need to pass all the varargs (ignoring 'str')
            // to String.format. arguments is not a std 'Array' so must first be converted via 'slice'
            str = String.prototype.format.apply(str, Array.prototype.slice.apply(arguments).slice(1));
        }

        if (window.widget) {
            alert(str);
        } else {
            var debugDiv = document.getElementById('debugDiv');
            debugDiv.appendChild(document.createTextNode(str));
            debugDiv.appendChild(document.createElement("br"));
            debugDiv.scrollTop = debugDiv.scrollHeight;
        }
    }
}

// Toggle the debugMode flag, but only show the debugDiv in Safari
function setupDebugMode() 
{
    if (debugMode == true && !window.widget) {
        document.getElementById('debugDiv').style.display = 'block';
    } else {
        document.getElementById('debugDiv').style.display = 'none';
    }
}

function getCssRuleBySelector( selector )
{
    if ( !selector )
        return null;

    var cssRules = document.styleSheets[0].cssRules;
    var slower = selector.toLowerCase();
    for ( var i = 0; i < cssRules.length; ++i ) {
        if ( cssRules[i].selectorText.toLowerCase() == slower )
            return cssRules[i];
    }
    debug( "Warning: Unable to find CSS rule selector: " + selector );
    return null;
}

/*
jQuery.fn.tooltip = function() {
    if ( arguments.length ) {
        var title = arguments[0];
        this.each(function() {
                this.setAttribute('title', title);
            });
    }
    else {
        var tooltip = '';
        this.each(function() {
                if ( this.hasAttribute('title') )
                    tooltip += ' ' + this.getAttribute('title');
            });
        return tooltip;
    }
};

jQuery.fn.removeTooltip = function() {
    this.each(function() {
            this.removeAttribute('title');
        });
};
*/

jQuery.fn.appendImage = function(src) {
    this.each( function() {
            var img = document.createElement('img');
            img.setAttribute('src', src);
            this.appendChild(img);
        });
};


/** 
  This prototype is provided by the Mozilla foundation and
  is distributed under the MIT license.
  http://www.ibiblio.org/pub/Linux/LICENSES/mit.license
*/
if (!Array.prototype.forEach)
{
    Array.prototype.forEach = function(fun /*, thisp*/) {
        if (typeof fun != "function")
            throw new TypeError();

        var thisp = arguments[1];
        var len = this.length;
        for (var i = 0; i < len; i++) {
            if (i in this)
                fun.call(thisp, this[i], i, this);
        }
    };
}

/** Replace all instances of %s with the string representation of each vararg object.
    Returns (by copy) the formatted string.
    Uses the 'arguments' function property to extract variable arguments :)
 */
String.prototype.format = function(/* varargs */) {
    var match = '%s';
    if ( arguments.length == 0 ) {
        return this.slice(0); // return a copy
    }
    else if ( arguments.length == 1 ) {
        return this.replace(match, String(arguments[0]));
    }
    else {
        var startIdx = 0;
        var format = this.slice(0);
        for (var i=0; i<arguments.length; ++i ) {
            var idx = format.indexOf(match, startIdx);
            if ( idx >= 0 ) {
                var arg = String(arguments[i]);
                format = format.substr(0, idx) + arg + format.substr(idx+match.length);
                startIdx = idx + arg.length;
            }
            else
                throw 'String.format has badly formatted string';
        }
        return format;
    }
};

String.prototype.strip = function() 
{
    var stripped = this.slice(0);
    while ( stripped.match(/^\s/) )
        stripped = stripped.slice(1);
    while ( stripped.match(/\s$/) )
        stripped = stripped.slice(0,-1);
    return stripped;
};

String.prototype.toLeadingUpperCase = function()
{
    if ( this.length )
        return this[0].toUpperCase() + this.substring( 1 );
    else
        return this.slice(0); // copy
}

String.prototype.toCamelCase = function()
{
    var result = '';
    var split = this.split();
    for ( var i=0; i<split.length; ++i )
        result += split[i].toLeadingUpperCase();
    return result;
}

String.prototype.hasPrefix = function(prefix) {
    if ( !prefix || prefix.length == 0 || this.length < prefix.length )
        return false;
    else
        return (this.substr(0, prefix.length) == prefix);
};

String.prototype.hasSuffix = function(suffix) {
    if ( !suffix || suffix.length == 0 || this.length < suffix.length )
        return false;
    else
        return (this.substr(this.length - suffix.length) == suffix);
};

String.prototype.firstMatch = function(re) {
    var m = this.match(re);
    if ( m && m.length >= 2 )
        return m[1];
    else
        return undefined;
};
