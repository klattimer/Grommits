/** BBC Weather widget: Fetches info from the BBC's wap weather source 
    
    Copyright: John Buckley (cocoa.coder@gmail.com)
    July 2005

    DISCLAIMER: This computer program is supplied "AS IS".
    The Author disclaims all warranties, expressed or implied, including,
    without limitation, the warranties of merchantability and of fitness
    for  any purpose.  The Author assumes no liability for direct, indirect,
    incidental, special, exemplary, or consequential damages, which may
    result from the use of the computer program, even if advised of the
    possibility of such damage.  There is no warranty against interference
    with your enjoyment of the computer program or against infringement.
    There is no warranty that my efforts or the computer program will
    fulfill any of your particular purposes or needs.  This computer
    program is provided with all faults, and the entire risk of satisfactory
    quality, performance, accuracy, and effort is with the user.

    LICENSE: Permission is hereby irrevocably granted to everyone to use,
    copy, modify, and distribute this computer program, or portions hereof,
    purpose, without payment of any fee, subject to the following
    restrictions:

    1. The origin of this binary or source code must not be misrepresented.

    2. Altered versions must be plainly marked as such and must not be
    misrepresented as being the original binary or source.

    3. The Copyright notice, disclaimer, and license may not be removed
    or altered from any source, binary, or altered source distribution.
*/

var DEG = "\u00b0"; // &#176
var ENDASH = "\u2013";
var EMDASH = "\u2014";

// Images
// Sigh - the Beeb seem to use more than one description for each weather "type"
var largeIcons = {
    "sunny" : "large_icons/32.png",  // Could use 36.png if hot
    "sunny-night" : "large_icons/31.png",
    "sunny-intervals" : "large_icons/30.png",
    "sunny-intervals-night" : "large_icons/29.png",

    // clear - psuedonym for sunny
    "clear" : "large_icons/32.png",
    "clear-intervals" : "large_icons/30.png",

    "light-shower" : "large_icons/39.png",
    "light-rain-shower" : "large_icons/39.png",
    "light-rain" : "large_icons/11.png",
    "heavy-rain" : "large_icons/40.png",  
    "heavy-shower" : "large_icons/12.png",     // These two could be 39 too :(
    "heavy-rain-shower" : "large_icons/12.png",
    "drizzle" : "large_icons/11.png",

    "thundery-shower" : "large_icons/37.png",
    "thunderstorm" : "large_icons/35.png",

    "cloudy-with-sleet" : "large_icons/5.png",
    "sleet-shower" : "large_icons/5.png",
    "sleet" : "large_icons/5.png",
    "cloudy-with-hail" : "large_icons/6.png",
    "hail-shower" : "large_icons/6.png",
    "hail" : "large_icons/6.png",

    "light-snow" : "large_icons/14.png",
    "light-snow-shower" : "large_icons/14.png",
    "cloudy-with-light-snow" : "large_icons/14.png",
    "heavy-snow" : "large_icons/16.png",  
    "heavy-snow-shower" : "large_icons/16.png",
    "cloudy-with-heavy-snow" : "large_icons/16.png",

    "cloudy" : "large_icons/28.png", // with a bit of sun :)
    "partly-cloudy" : "large_icons/28.png",
    "low-level-cloud" : "large_icons/26.png",
    "medium-level-cloud" : "large_icons/26.png",
    "white-cloud" : "large_icons/26.png",
    "grey-cloud" : "large_icons/26.png",

    "sandstorm" : "large_icons/na.png",
    "mist" : "large_icons/9.png",
    "misty" : "large_icons/9.png",
    "fog" : "large_icons/20.png",
    "foggy" : "large_icons/20.png",
    "tropical-storm" : "large_icons/1.png",
    "hazy" : "large_icons/34.png",

    "na" : "large_icons/na.png" // Not applicable
};

// Produced from largeIcons
var smallIcons = null;

var prefs = {
    mobileId : undefined, // 'legacy' id, used for the mobile forecast e.g. id=1855
    locationId : undefined, // 'new' location id e.g. 2345. Not persisted, but fetched each time the widget is setup
    locationShortName : undefined,
    locationLongName : undefined,
    useCelcius : true,
    themePath : '/icons/Samurize/',
    highlightExtremeTemp : true
};

var timerId = null;
var updateWeatherTimeout = 1000 * 60 * 30; // every 30mins if the widget is active

var observationRequest = null;
var wmlRequest = null;
var isLoadingForecastFrame = false;
var isLoadingObservations = false;

// Loading animation vars
var updateWeatherAnimTimerId = 0;
var loadingAnimData = new Array;

// Checking for updates
var lastVersionCheckTime = 0;
var lastVersionCheckDelay = 24 * 3600 * 1000; // 24 hrs in m
var versionNumber = undefined;

// Data urls
var observationsUrl = "http://news.bbc.co.uk/weather/forecast/%s/ObservationsRSS.xml";
var fiveDayMobileUrl = "http://www.bbc.co.uk/weather/mobile/5day.shtml?%s";
var fiveDayWmlUrl = "http://www.bbc.co.uk/weather/mobile/5day.wml?%s";
var fiveDayUrl = "http://www.bbc.co.uk/weather/5day.shtml?%s";

// External urls for launchBBCWebsite()
var bbcWeatherUrl = "http://news.bbc.co.uk/weather";
var bbcForecastUrl = "http://www.bbc.co.uk/weather/5day.shtml?%s";

/* DEBUG */
var debugMode = false;

function buildSmallIconArray()
{
    if ( smallIcons ) 
        return;

    smallIcons = {};
    for ( var key in largeIcons ) {
        smallIcons[key] = largeIcons[key].replace( "large_icons", "small_icons" );
    }
}

function createButton(parent, label, handler, handlerStr)
{
    try {
        createGenericButton( parent, label, handler );
    } 
    catch(e) { // Probably running under a pre 10.4 browser..
        var button = document.createElement( "button" );
        button.setAttribute( "onclick", handlerStr );
        button.appendChild( document.createTextNode(label) );
        parent.appendChild( button );
    }
}

function setup()
{
    setupDebugMode();
    buildSmallIconArray();

    // buttons
    createButton(document.getElementById("done-button"), 'Done', hidePrefs, 'hidePrefs()');
    createButton(document.getElementById("search-button"), 'Go', validateLocationInput, 'validateLocationInput()');

    // new version tooltip
    setTooltip('#new-version-badge', 'A new version is available, click for more info');
    $('#new-version-badge').bind('click', openNewVersionUrl);

    // Fetch last city from preferences - default to Edinburgh :)
    if ( window.widget ) {
        readPrefs();
    }

    if ( !prefs.mobileId ) {
        // Edinburgh
        prefs.mobileId = 'id=1808';
        prefs.locationId = null; // fetched from bbc
        prefs.locationShortName = "Edinburgh";
        prefs.locationLongName = "Edinburgh";
        prefs.useCelcius = true;
        prefs.themePath = "icons/Samurize/";
    }

    debug( "Using mobileId: %s", prefs.mobileId );

    if ( window.widget ) {
        window.widget.onshow = onshow;
        window.widget.onhide = onhide;
        window.widget.onremove = onremove;
    }

    onshow();
}

function onremove()
{
    storePrefs();
}

function onshow()
{
    hidetip();

    if ( !timerId ) {
        timerId = setInterval( "updateWeatherData();", updateWeatherTimeout );
    }

    updateWeatherData();

    // check for updates if it is 24hrs or more since the last check (or first launch)
    var now = new Date();
    if ( (now.getTime() - lastVersionCheckTime) > lastVersionCheckDelay ) {
        checkForUpdates();
        lastVersionCheckTime = now.getTime();
    }
}

function onhide()
{
    hidetip();

    // Clear our timer
    if ( timerId ) {
        clearInterval( timerId );
        timerId = 0;
    }
}

function isForecastLoading()
{
    return (isLoadingForecastFrame || isLoadingObservations);
}

function updateObservations()
{
    if ( observationRequest ) 
        observationRequest.abort();

    debug('Fetching observations: %s', observationsUrl.format(prefs.locationId));
    observationRequest = createXMLRequest(observationsUrl.format(prefs.locationId), parseObservations);
    observationRequest.send();
}

function updateForecast()
{
    debug('Fetching forecast: %s', fiveDayWmlUrl.format(prefs.mobileId));
    isLoadingForecastFrame = true;

    if ( wmlRequest )
        wmlRequest.abort();
    wmlRequest = createXMLRequest(fiveDayWmlUrl.format(prefs.mobileId), parseWml);
    wmlRequest.overrideMimeType('text/xml');
    wmlRequest.send();
}

function updateWeatherData()
{
    // Abort any current requests
    if ( observationRequest ) 
        observationRequest.abort();

    setLocationText();

    // If we don't yet have a locationId then fetch it via the non-mobile 5day forecast URL.
    // This helpfully redirects to the 'new' location providing us with the new id.
    // Note that yet again we have to use an iframe because XMLHttpRequest a) doesn't provide the redirect URL
    // and b) fails to parse the content xml document.
    isLoadingObservations = true;
    if ( prefs.locationId == null ) {
        debug('Fetching locationId: %s', fiveDayUrl.format(prefs.mobileId));
        searchFrame().onload = handleLocationIdRequest;
        searchFrame().src = fiveDayUrl.format(prefs.mobileId);
    }
    else {
        // Get current temp from ObservationsRSS.xml
        updateObservations();
    }

    updateForecast();

    // Loading animation
    if ( !updateWeatherAnimTimerId ) {
        updateWeatherAnimTimerId = setInterval( function() { loadingAnimation(updateWeatherAnimTimerId) }, 500 );
        loadingAnimData[updateWeatherAnimTimerId] = { text:"Loading", node:"#location", count:3 };
    }
    loadingAnimation(updateWeatherAnimTimerId);
}

function handleLocationIdRequest(event, request)
{
    var contentDocument = searchFrame().contentDocument;
    if ( contentDocument.URL == 'about:blank' )
        return;

    if ( contentDocument.readyState != 'complete' ) {
        searchFrame().src = 'about:blank';
        handleObservations({errorString:"Location id request failed"});
        return;
    }

    prefs.locationId = contentDocument.URL.firstMatch(/\/weather\/forecast\/([0-9]+)/);

    searchFrame().src = 'about:blank'; // reset

    if ( prefs.locationId ) {
        storePrefs();
        updateObservations();
    }
    else
        handleObservations({errorString:"No location id found"});
}

function parseObservations(event, request)
{
    if ( request.status != 200 || !request.responseXML ) {
        handleObservations({errorString:"Invalid response"});
        return;
    }

    // Parse the data
    //var title = $("item title", request.responseXML).text();
    var description = $("item description", request.responseXML).text();
    //var pubDate = $("item pubDate", request.responseXML).text();

    if ( !description ) {
        handleObservations({errorString:"No observation data"});
        return;
    }

    var result = {};

    // e.g. Tuesday at 15:00 GMT: sunny intervals. 9°C (48°F)
//     var m = title.match(/\s+([a-z ]+)\./ig);
//     if ( m )
//         result.summary = m[0].slice(0, -1).strip();

    // Parse the description. It's almost valid JSON, but not quite...
    // e.g. Temperature: 7°C (45°F), Wind Direction: SW, Wind Speed: 10mph, Relative Humidity: 84%, Pressure: 997mB, rising, Visibility: Excellent
    var data = {};
    description = description.replace('mB,', 'mB'); // remove spurious comma
    description.split(',').forEach( function(item) {
            var m = item.match(/([a-z]+):(.+)/i);
            if ( m && m.length == 3 ) {
                var key = m[1].toLowerCase();
                if ( key == 'temperature' )
                    result.temperature = parseInt(m[2]);
                else if ( key == 'direction' || key == 'speed' )
                    result.wind = (result.wind ? m[2] + ' (%s)'.format(result.wind) : m[2].strip());
                else if ( key == 'pressure' )
                    result.pressure = m[2].replace('mB', 'mB,').replace('Rising', 'rising').replace('Falling', 'falling');
                else
                    result[key] = m[2];
            }
        });

    handleObservations(result);
}

function handleObservations(result)
{
    observationRequest = null;
    isLoadingObservations = false;
    clearWeatherUpdateTimer();
    $('#current-temp').css('color', getHighColorForTemp(1)); // reset

    if ( result.errorString || result.temperature == undefined || isNaN(result.temperature) ) {
        debug('handleObservations error: %s', result.errorString);
        setTextAndTooltip( '#current-temp', EMDASH, "No current weather data available" );
        clearTooltip('#large-icon');
        clearTooltip('#large-icon img');
        return;
    }

    // Temperature
    if ( result.temperature != undefined ) {
        $('#current-temp').text( convertTemp(result.temperature) + DEG );
        $('#current-temp').css('color', getHighColorForTemp(result.temperature));
    }

    // Conditions tooltip
    var tooltip = getForecastInfoTooltip(result);
    if ( tooltip.length ) {
        setTooltip('#current-temp', tooltip);
        setTooltip('#large-icon', tooltip);
        setTooltip('#large-icon img', tooltip);
    }
    else {
        clearTooltip('#current-temp');
        clearTooltip('#large-icon');
        clearTooltip('#large-icon img');
    }
}

function parseWml(event, request) 
{
    var result = {};
    result.today = {};
    result.days = [];

    if ( request.status != 200 || !request.responseXML ) {
        result.errorString = "Request failed";
        handleHTMLData(result);
        return;
    }

    function parseDay(day, node) {
        day.name = node.text();
        var data = [];
        var next = node.get(0).nextSibling;
        while( next ) {
            if ( next.nodeType == 3 ) // text
                data.push(next.data.strip());
            else if ( next.tagName == 'br' && next.nextSibling && next.nextSibling.tagName == 'br' )
                break;
            next = next.nextSibling;
        }

        if ( data.length == 4 ) {
            day.summary = data[0].toCamelCase();
            day.high = data[1].firstMatch(/Max:?\s*(\-?[0-9]+)/i);
            day.low = data[2].firstMatch(/Min:?\s*(\-?[0-9]+)/i);
            day.wind = data[3].firstMatch(/Wind:?\s*([0-9]+\s*mph\s+\([a-z]{1,3}\))/i);
        }
    };


    // Parse the data
    try {
        var responseXML = request.responseXML;
        result.location = $('card p b:first', responseXML).text();

        // Today
        parseDay(result.today, $('card p b:eq(1)', responseXML));

        // Next 4 days
        $('card p b:gt(1)', responseXML).each( function() {
                var day = {};
                parseDay(day, $(this));

                if ( day.name != undefined 
                     && day.high != undefined
                     && day.low != undefined
                     && day.summary != undefined ) {
                    
                    result.days.push(day);
                }
            } );
    }
    catch(e) {
        debug('parseHTML catch: %s', e);
        result.errorString = e.toString();
    }

    handleHTMLData(result);
}

/*
function forecastFrameDidLoad() 
{
    var doc = forecastFrame().contentDocument;
    if ( doc.URL == 'about:blank' )
        return;

    debug('forecastFrameDidLoad: %s', doc.readyState);

    var result = {};
    result.today = {};
    result.days = [];

    if ( doc.readyState != 'complete' ) {
        result.errorString = "Request failed";
        handleHTMLData(result);
        return;
    }

    function parseDay(day, node) {
        var text = node.text();
        day.name = text.firstMatch(/\b(\w+)\b/);
        day.summary = $('h3', node).text().toCamelCase();
        day.high = text.firstMatch(/Max:\s*(\-?[0-9]+)/i);
        day.low = text.firstMatch(/Min:\s*(\-?[0-9]+)/i);
        var dir = text.firstMatch(/Wind Dir:\s*([a-z]{1,2})/i);
        var speed = text.firstMatch(/Wind Sp:\s*([0-9]+\s+mph)/i);
        day.wind = dir + ', ' + speed;
    };

    // Parse the data
    try {
        result.location = $('.content h1', doc).text().firstMatch(/5\s+day\s+forecast\s+for\s+(.+)/i);

        // Today
        parseDay(result.today, $('.promBox:first', doc));

        // Next 4 days
        $('.promBox:gt(0)', doc).each( function() {
                var day = {};
                parseDay(day, $(this));

                if ( day.name != undefined 
                     && day.high != undefined
                     && day.low != undefined
                     && day.summary != undefined ) {
                    
                    result.days.push(day);
                }
            } );
    }
    catch(e) {
        debug('parseHTML catch: %s', e);
        result.errorString = e.toString();
    }

    handleHTMLData(result);
}
*/

function handleHTMLData(result)
{
    wmlRequest = null;
    isLoadingForecastFrame = false;
    clearWeatherUpdateTimer();

    // Check for an error or complate lack of data
    if ( result.errorString 
         || !result.today || result.today.summary == undefined
         || !result.days || result.days.length == 0 ) 
        {
        debug('Warning: Fetching data failed, ' + result.errorString);

        //dumpObject(result.today, 'today');
        //debug('days: %s', result.days.length);

        setTextAndTooltip( '#current-temp', EMDASH, "No current weather data available" );
        clearTooltip("#large-icon");
        clearTooltip("#current-temp");

        clearAllForecasts();
        setTextAndTooltip( "#location", "No forecast data", result.errorString );

        // If we were validating a location then flag up the problem here
        if ( validateAnimTimerId )
            endLocationValidation( "No forecast data" );
        return;
    }

    function setTemp( node, temp, getColor ) {
        node = $(node);
        if ( temp != undefined ) {
            node.text( convertTemp(temp) + DEG );
            node.css('color', getColor(temp));
        }
        else {
            node.text('');
            node.css('color', getColor(1));
        }
    }

    // If our current location looks like a postcode then replace it with the actual location
    if ( result.location && prefs.locationShortName.match(/\b[a-z]{1,2}[0-9]{1,2}\b/i) ) {
        prefs.locationShortName = result.location;
        prefs.locationLongName = result.location;
        $('#location-input').val(prefs.locationShortName);
    }

    // Today
    $('#today-summary').text(result.today.summary.toLeadingUpperCase());
    $('#large-icon').empty();
    $('#large-icon').appendImage(getIconUrlForKey(largeIcons, result.today.summary));
    if ( $('#large-icon').attr('tiptext') )
        setTooltip('#large-icon img', $('#large-icon').attr('tiptext') );

    setTemp('#today-high-temp', result.today.high, getHighColorForTemp);
    setTemp('#today-low-temp', result.today.low, getLowColorForTemp);

    // Next 4 days
    function isExtremeTemp( tempC ) {
        var convertedT = convertTemp( tempC );
        // We're really interested in the no. of displayed digits, not the abs temp
        return ( convertedT < 0 || convertedT > 99 );
    }

    var extremeTemp = false;
    var bothExtremeTemp = false;

    for ( var i=0; i < result.days.length; ++i ) {
        var day = result.days[i];
        var id = i + 1;

        $('#day%s'.format(id)).text(day.name.substr(0,3));
        setTemp('#day%s-high-temp'.format(id), day.high, getHighColorForTemp);
        setTemp('#day%s-low-temp'.format(id), day.low, getLowColorForTemp);

        extremeTemp = (isExtremeTemp( day.low ) || isExtremeTemp( day.high ) || extremeTemp);
        bothExtremeTemp = ((isExtremeTemp( day.low ) && isExtremeTemp( day.high )) || bothExtremeTemp);

        var tooltip = getForecastInfoTooltip(day);
        tooltip = '<div style="margin-bottom:4px"><strong>' + day.summary + '</strong></div>' + tooltip;
        setImage('#day%s-icon'.format(id), getIconUrlForKey(smallIcons, day.summary.toLowerCase()), tooltip);
    }

    // Check for extreme temps and set font-size appropriately
    var highFontSize = "13px";
    var lowFontSize = "11px";
    if ( extremeTemp ) {
        highFont = bothExtremeTemp ? "11px" : "12px";
        lowFont = bothExtremeTemp ? "9px" : "10px";
    }

    getCssRuleBySelector( 'span.high-temp' ).style.fontSize = highFontSize;
    getCssRuleBySelector( 'span.low-temp' ).style.fontSize = lowFontSize;
}

function getForecastInfoTooltip(forecast) 
{
    var tooltip = '';
    var keys = ['wind', 'pressure', 'humidity', 'visibility', 'sunrise', 'sunset'];
    keys.forEach( function(key) {
        if ( forecast[key] ) {
            if ( tooltip.length )
                tooltip += '\n';
            tooltip += '%s: %s'.format(key.toLeadingUpperCase(), forecast[key]);
        }
    });
    return tooltip;
}

function setTextAndTooltip( node, str, tooltip ) 
{
    node = $(node);
    // Replace minus sign with narrower EN DASH
    node.text(str.replace( /^\-/, ENDASH ));
    if ( tooltip )
        setTooltip(node, tooltip);
    else 
        clearTooltip(node);
}

function setTooltip( node, tooltip ) {
    node = $(node);
    // translate \n to <br/>
    tooltip = tooltip.replace( /\n/g, "<br/>" );
    node.attr( "tiptext", tooltip );
    node.bind( "mouseover", showtip );
    node.bind( "mouseout", hidetip );
    node.bind( "mousemove", movetip );
}

function clearTooltip( node ) {
    node = $(node);
    if ( node.attr( "tiptext" ) != undefined ) {
        node.removeAttr( "tiptext" );
        node.unbind('mouseover mouseout mousemove');
    }
}

function setImage( node, src, tooltip ) {
    node = $(node);
    node.empty();
    node.appendImage(src);
    if ( tooltip )
        setTooltip( $(':last', node), tooltip);
    else
        clearTooltip($(':last', node));
}

function clearAllForecasts() 
{
    $('#location').empty();
    $('#large-icon').empty();
    ['#today-summary', '#current-temp', '#today-high-temp', '#today-low-temp'].forEach(function(id) {
            $(id).text('');
            clearTooltip(id);
        });

    for ( var i=1; i<5; ++i ) {
        $('#day%s-icon'.format(i)).empty();
        ['#day%s', '#day%s-high-temp', '#day%s-low-temp'].forEach(function(id) {
                var node = $(id.format(i));
                node.text('');
                clearTooltip(node);
        });
    }
}

function convertTemp( tempC )
{
    // Assumes temp is always in celcius
    if ( prefs.useCelcius ) {
        return tempC;
    }
    else {
        // Round to the nearest degree
        return Math.round( 9 * tempC / 5 + 32 );
    }
}

function getHighColorForTemp( tempC ) {
    if ( !prefs.highlightExtremeTemp ) return "#ffffff";

    if ( tempC <= 0 ) return "#91fffe";
    if ( tempC > 30 ) return "#bf0000";

    return "#ffffff"; // default
}

function getLowColorForTemp( tempC ) {
    if ( !prefs.highlightExtremeTemp ) return "#d3d3d3";

    if ( tempC <= 0 ) return "#91fffe";
    if ( tempC > 30 ) return "#bf0000";

    return "#d3d3d3"; // default
}

function setLocationText()
{
    var location = prefs.locationShortName;
    if ( !location || location.length == 0 )
        location = "No Location";
    else if ( location.length > 16 )
        location = location.substr( 0, 16 ) + "...";

    var node = $('#location');
    node.text(location);

    if ( prefs.locationLongName )
        setTooltip(node, prefs.locationLongName);
    else
        clearTooltip(node);
}

function clearWeatherUpdateTimer()
{
    // Wait for both the WAP and HTML requests to complete
    if ( isForecastLoading() )
        return;

    if ( updateWeatherAnimTimerId ) {
        clearInterval( updateWeatherAnimTimerId );
        loadingAnimData[updateWeatherAnimTimerId] = undefined;
        updateWeatherAnimTimerId = 0;
        setLocationText(); // reset 'Loading...'
    }
}

function getIconUrlForKey( iconSet, key )
{
    key = key.toLowerCase();
    key = key.replace( /\s/g, "-" );

    if ( iconSet[key] ) {
        return prefs.themePath + iconSet[key];
    }

    // If we didn't find it then try removing any trailing 's'
    key = key.replace( /s$/, "" );
    if ( iconSet[key] ) {
        return prefs.themePath + iconSet[key];
    }

    debug( "Warning: Could not find '" + key + "' in iconset" );
    return prefs.themePath + iconSet["na"]; // not applicable
}

// Handles a 'loading' text animation for multiple timers
function loadingAnimation( id )
{
    var text = loadingAnimData[id].text;
    var count = loadingAnimData[id].count;

    for ( var i = 0; i < count; ++i )
        text += ".";
        
    $(loadingAnimData[id].node).text(text);

    if ( count == 3 )
        loadingAnimData[id].count = 0;
    else
        ++loadingAnimData[id].count;
}

function openUrl( url )
{
    if ( window.widget ) {
        window.widget.openURL( url );
    }
    else {
        window.open( url );
    }
}

function launchBBCWebsite()
{
    if ( prefs.mobileId )
        openUrl(bbcForecastUrl.format(prefs.mobileId));
    else
        openUrl(bbcWeatherUrl);
}

