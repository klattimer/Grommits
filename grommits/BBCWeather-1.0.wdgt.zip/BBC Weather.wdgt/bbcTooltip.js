/** BBC Weather widget: Fetches info from the BBC's wap weather source 
    
    Copyright: John Buckley (cocoa.coder@gmail.com)
    July 2005

    DISCLAIMER: This computer program is supplied "AS IS".
    The Author disclaims all warranties, expressed or implied, including,
    without limitation, the warranties of merchantability and of fitness
    for  any purpose.  The Author assumes no liability for direct, indirect,
    incidental, special, exemplary, or consequential damages, which may
    result from the use of the computer program, even if advised of the
    possibility of such damage.  There is no warranty against interference
    with your enjoyment of the computer program or against infringement.
    There is no warranty that my efforts or the computer program will
    fulfill any of your particular purposes or needs.  This computer
    program is provided with all faults, and the entire risk of satisfactory
    quality, performance, accuracy, and effort is with the user.

    LICENSE: Permission is hereby irrevocably granted to everyone to use,
    copy, modify, and distribute this computer program, or portions hereof,
    purpose, without payment of any fee, subject to the following
    restrictions:

    1. The origin of this binary or source code must not be misrepresented.

    2. Altered versions must be plainly marked as such and must not be
    misrepresented as being the original binary or source.

    3. The Copyright notice, disclaimer, and license may not be removed
    or altered from any source, binary, or altered source distribution.
*/

var _tip_timer_id = 0;
var _event = null;

function showtip( event ) {
    //debug( "showtip: " + _tip_timer_id );

    // Set a timer which will eventually show the tip
    if ( _tip_timer_id == 0 ) {
        hidetip();
        _event = event;
        _tip_timer_id = setTimeout( "private_showtip()", 500 ); // ms
    }
}

function movetip( event ) {
    // Update event so we have correct coordiantes
    if ( _event ) 
        _event = event;
}

function private_showtip() 
{
    _tip_timer_id = 0;
    if ( !_event ) 
        return;

    var tip_text = _event.target.getAttribute('tiptext');
    //debug( "tip_text: " + tip_text );
    if( !tip_text ) return; 
	
    var tooltip = document.getElementById("tooltip");
    tooltip.innerHTML = tip_text;
    
    // Makes the "tooltip" element visible and moves it to the (x,y) of the mouse event (plus some buffer zone)
    var xcoord = 0;
    var ycoord = 0;
    
    if ( _event.pageX || _event.pageY ) {
        xcoord = _event.pageX;
        ycoord = _event.pageY;
    } 
    else if ( _event.clientX || _event.clientY) {
        xcoord = _event.clientX + (document.documentElement.scrollLeft ?  document.documentElement.scrollLeft : document.body.scrollLeft);
        ycoord = _event.clientY + (document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop);
    }

    xcoord += 4;
    ycoord += 10;

    // Check we don't over-flow the doc
    if ( xcoord + tooltip.clientWidth > document.clientWidth ) {
        xcoord = document.clientWidth - tooltip.clientWidth;
        if ( xcoord < 0 ) xcoord = 0;
    }

    if ( ycoord + tooltip.clientHeight > document.clientHeight ) {
        ycoord = document.clientHeight - tooltip.clientHeight;
        if ( ycoord < 0 ) ycoord = 0;
    }

    tooltip.style.left = xcoord + "px";
    tooltip.style.top = ycoord + "px";
    tooltip.style.visibility="visible";

    // reset
    _event = null;
}

function hidetip() {
    document.getElementById("tooltip").style.visibility="hidden";

    if ( _tip_timer_id ) {
        clearTimeout( _tip_timer_id );
        _tip_timer_id = 0;
    }

    _event = null;
}
